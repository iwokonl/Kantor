export class AppExeption {
  message: string;
  httpStatus: number;
}