package pl.zeto.backend.VMC.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import pl.zeto.backend.VMC.model.CurrencyData;
import pl.zeto.backend.VMC.service.CurrencyService;

@RestController
public class CurrencyController {

    private final CurrencyService currencyService;

    public CurrencyController(CurrencyService currencyService) {
        this.currencyService = currencyService;
    }

    @GetMapping("/currency/{code}")
    public ResponseEntity<CurrencyData> getCurrencyRate(@PathVariable String code) {
        CurrencyData currencyData = currencyService.getCurrencyRate(code);
        if (currencyData != null) {
            return ResponseEntity.ok(currencyData);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
