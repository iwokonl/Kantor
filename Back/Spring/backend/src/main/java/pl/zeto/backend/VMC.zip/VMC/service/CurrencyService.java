package pl.zeto.backend.VMC.service;

import lombok.Data;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import pl.zeto.backend.VMC.controller.CurrencyRepository;
import pl.zeto.backend.VMC.model.Currency;
import pl.zeto.backend.VMC.model.CurrencyData;

import java.util.List;
@Data
@Service
public class CurrencyService {

    private final CurrencyRepository currencyRepository;

    public CurrencyService(CurrencyRepository currencyRepository) {
        this.currencyRepository = currencyRepository;
    }

    public void updateCurrencies() {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://api.nbp.pl"; // Podmień na właściwy URL
        // Przykład zapytania, dostosuj do struktury API NBP
        CurrencyData[] currencyData = restTemplate.getForObject(url, CurrencyData[].class);
        for (CurrencyData data : currencyData) {
            Currency currency = new Currency(data.getCode(), data.getName(), data.getExchangeRate());
            currencyRepository.save(currency);
        }
    }
}
