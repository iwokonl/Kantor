package pl.zeto.backend.VMC.model;


public enum Role {
    ADMIN,
    USER
    // Możesz dodać więcej ról zgodnie z wymaganiami twojego systemu
}
