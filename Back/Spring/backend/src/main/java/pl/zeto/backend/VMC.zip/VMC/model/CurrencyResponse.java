package pl.zeto.backend.VMC.model;

import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
public class CurrencyResponse {
    private String currency;
    private List<Rate> rates;

    @Getter
    @Setter
    public static class Rate {
        private Double mid;
    }
}
