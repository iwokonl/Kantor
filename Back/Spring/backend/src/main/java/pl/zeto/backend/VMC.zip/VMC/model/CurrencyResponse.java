package pl.zeto.backend.VMC.model;

public class CurrencyResponse {
    private Double mid;

    // Gettery i settery
    public Double getMid() {
        return mid;
    }

    public void setMid(Double mid) {
        this.mid = mid;
    }
}