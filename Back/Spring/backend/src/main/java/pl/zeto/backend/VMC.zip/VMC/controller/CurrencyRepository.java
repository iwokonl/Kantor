package pl.zeto.backend.VMC.controller;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.zeto.backend.VMC.model.Currency;

public interface CurrencyRepository extends JpaRepository<Currency, Long> {
    // Tu można dodać metody zapytań, jeśli są potrzebne
}